--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS '';


--
-- Name: account_status; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.account_status AS ENUM (
    'DELETE',
    'ACTIVE',
    'SUSPEND'
);


ALTER TYPE public.account_status OWNER TO admin;

--
-- Name: usage_status; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.usage_status AS ENUM (
    'OFFLINE',
    'ONLINE'
);


ALTER TYPE public.usage_status OWNER TO admin;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.user_role AS ENUM (
    'USER',
    'ADMIN',
    'HOSPITAL',
    'MERCHANT',
    'TOUR',
    'LEARNING_RESOURCE',
    'HOTEL',
    'SEASONAL_TRAVEL'
);


ALTER TYPE public.user_role OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO admin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id integer NOT NULL,
    firstname character varying(150) NOT NULL,
    lastname character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    password character varying(60) NOT NULL,
    tel character varying(20) NOT NULL,
    profilepicture character varying(150) DEFAULT 'default-profile.jpg'::character varying NOT NULL,
    role public.user_role DEFAULT 'USER'::public.user_role NOT NULL,
    usage_status public.usage_status DEFAULT 'OFFLINE'::public.usage_status NOT NULL,
    statuslastupdate timestamp(6) without time zone,
    account_status public.account_status DEFAULT 'ACTIVE'::public.account_status NOT NULL,
    createdat timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp(6) without time zone
);


ALTER TABLE public.users OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
dc2a4d40-b874-42bf-8cb5-659cfad30a7b	bafa69108c637b1116aad92b8ff8d49624d4763c86df169ad78fb4bdfc3ed856	2024-09-26 21:58:06.705082+00	20240926215806_users	\N	\N	2024-09-26 21:58:06.697488+00	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (id, firstname, lastname, email, password, tel, profilepicture, role, usage_status, statuslastupdate, account_status, createdat, updatedat) FROM stdin;
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--


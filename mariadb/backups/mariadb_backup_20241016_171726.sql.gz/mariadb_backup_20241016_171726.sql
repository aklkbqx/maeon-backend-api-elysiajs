/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.5.2-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: maeon_db
-- ------------------------------------------------------
-- Server version	11.5.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES
('388639aa-e827-41d3-97a0-5a89c3aa5554','4ba64eea72335927a792e10870670b83e7b0718aac50953277c413893d602d3a','2024-09-27 11:37:12.637','20240927113712_init',NULL,NULL,'2024-09-27 11:37:12.571',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accommodation`
--

DROP TABLE IF EXISTS `accommodation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accommodation` (
  `id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `address` text NOT NULL,
  `contact` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`contact`)),
  `interest` text DEFAULT NULL,
  `product` text DEFAULT NULL,
  `activites` text DEFAULT NULL,
  `check-in` text DEFAULT NULL,
  `check-out` text DEFAULT NULL,
  `health` text DEFAULT NULL,
  `date_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`date_info`)),
  `service_fee` text DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accommodation`
--

LOCK TABLES `accommodation` WRITE;
/*!40000 ALTER TABLE `accommodation` DISABLE KEYS */;
/*!40000 ALTER TABLE `accommodation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attractions`
--

DROP TABLE IF EXISTS `attractions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attractions` (
  `id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `address` text NOT NULL,
  `contact` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`contact`)),
  `interest` text DEFAULT NULL,
  `product` text DEFAULT NULL,
  `activites` text DEFAULT NULL,
  `health` text DEFAULT NULL,
  `date_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`date_info`)),
  `service_fee` text DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attractions`
--

LOCK TABLES `attractions` WRITE;
/*!40000 ALTER TABLE `attractions` DISABLE KEYS */;
/*!40000 ALTER TABLE `attractions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `program_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `people` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('PENDING','CONFIRMED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES
(1,2,1,'2024-10-11','2024-10-12','2024-10-12',1,500.00,'CONFIRMED','2024-10-11 07:55:13','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_resources`
--

DROP TABLE IF EXISTS `learning_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `learning_resources` (
  `id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `address` text NOT NULL,
  `contact` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`contact`)),
  `interest` text DEFAULT NULL,
  `product` text DEFAULT NULL,
  `activites` text DEFAULT NULL,
  `health` text DEFAULT NULL,
  `time_per_cycle` int(11) DEFAULT NULL,
  `people_per_cycle` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `advance_booking` int(11) DEFAULT NULL,
  `date_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`date_info`)),
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_resources`
--

LOCK TABLES `learning_resources` WRITE;
/*!40000 ALTER TABLE `learning_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `learning_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_types`
--

DROP TABLE IF EXISTS `location_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_types`
--

LOCK TABLES `location_types` WRITE;
/*!40000 ALTER TABLE `location_types` DISABLE KEYS */;
INSERT INTO `location_types` VALUES
(1,'สถานที่ท่องเที่ยว','2024-09-27 10:17:49'),
(2,'ที่พัก','2024-10-08 21:39:03'),
(3,'แหล่งเรียนรู้','2024-09-27 10:17:49'),
(4,'ร้านอาหาร','2024-09-27 10:17:49'),
(5,'โรงพยาบาล','2024-09-27 10:17:49');
/*!40000 ALTER TABLE `location_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `location_map` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`location_map`)),
  `time_slots` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` int(11) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`type`) REFERENCES `location_types` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `locations_ibfk_3` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES
(1,'โรงพยาบาลแม่ออน',5,'โรงพยาบาลชุมชนในอำเภอแม่ออน','{\"latitude\":99.221549,\"longitude\":18.743278}','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:51:48','0000-00-00 00:00:00'),
(2,'แม่กำปอง',1,'หมู่บ้านเล็กๆ ซ่อนตัวอยู่ท่ามกลางป่าเขาเขียวขจี มีความบริสุทธิ์ของธรรมชาติที่อุดมสมบูรณ์','{\"latitude\":18.865561,\"longitude\":99.349122}','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:53:44','0000-00-00 00:00:00'),
(3,'ศูนย์เรียนรู้แม่กำปอง',3,'ศูนย์เรียนรู้วิถีชีวิตชุมชนแม่กำปอง','{\"latitude\":18.865503,\"longitude\":99.349140}  ','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','0000-00-00 00:00:00'),
(4,'น้ำตกแม่กำปอง',1,'น้ำตกในชุมชนแม่กำปอง','{\"latitude\":99.355910,\"longitude\":18.862748}','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','0000-00-00 00:00:00'),
(5,'วัดคันธาพฤกษา',1,'วัดกลางน้ำในชุมชนแม่กำปอง','{\"latitude\":18.866115,\"longitude\":99.351996}','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','0000-00-00 00:00:00'),
(6,'ถนนคนเดินแม่กำปอง',1,'ถนนคนเดินในชุมชนแม่กำปอง มีอาหารพื้นบ้านและจุดถ่ายรูปหลากหลาย','{\"latitude\":18.865452,\"longitude\":99.350556}','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','0000-00-00 00:00:00'),
(7,'น้ำพุร้อนสันกำแพง',1,'แหล่งน้ำพุร้อนธรรมชาติ','{\"latitude\":18.814515,\"longitude\":99.229531}','[{\"start_time\":\"09:00\",\"end_time\":\"10:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:30\",\"end_time\":\"12:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"12:00\",\"end_time\":\"13:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:30\",\"end_time\":\"15:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"15:00\",\"end_time\":\"16:30\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:30\",\"end_time\":\"18:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `payment_method` enum('PROMPTPAY','BANK_ACCOUNT_NUMBER') DEFAULT NULL,
  `payment_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `slip_image` varchar(255) DEFAULT NULL,
  `status` enum('PENDING','PAID','FAILED','REFUNDED','PENDING_VERIFICATION','REJECTED') NOT NULL DEFAULT 'PENDING',
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `booking_id_2` (`booking_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,1,'PROMPTPAY',NULL,'2-1728676960281.jpeg','PAID','0041000600000101030040220014284130018COR076805102TH9104144A','2024-10-12 03:02:42','2024-10-11 07:55:13','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_types`
--

DROP TABLE IF EXISTS `program_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_types`
--

LOCK TABLES `program_types` WRITE;
/*!40000 ALTER TABLE `program_types` DISABLE KEYS */;
INSERT INTO `program_types` VALUES
(1,'โปรแกรมระยะสั้น (One-day trip)','8 มิติ Wellness ใน 8 โปรแกรมท่องเที่ยว เป็นโปรแกรมการท่องเที่ยวระยะสั้นที่จะได้ทั้งผ่อนคลายได้ท่องเที่ยวเรียนรู้ไปกับสถานที่ต่างๆภายใน 1 วันเต็ม','2024-09-25 17:55:26'),
(2,'โปรแกรมฟื้นฟูสุขภาพ (Long-day trip)','โปรแกรมท่องเที่ยวระยะยาวที่จะให้นักท่องเที่ยวได้ไปท่องเที่ยวหลายวันตามโปรแกรมที่กำหนด และยังได้การฟื้นฟูสุขภาพที่ดีขึ้นอีกด้วย','2024-09-25 17:55:26'),
(3,'โปรแกรมการท่องเที่ยวด้วยตัวเอง','กิจกรรมการท่องเที่ยวรูปแบบต่างๆ แยกตามตำบลของอำเภอแม่ออน ที่นักท่องเที่ยวสามารถจัดสรรค์เวลา เลือกจองการท่องเที่ยวเพื่อสุขภาพที่ไหนเองก็ได้ตามใจชอบ','2024-09-25 17:55:26');
/*!40000 ALTER TABLE `program_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `schedules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`schedules`)),
  `total_price` decimal(8,2) NOT NULL,
  `wellness_dimensions` text DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `programs_ibfk_1` FOREIGN KEY (`type`) REFERENCES `program_types` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `programs_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES
(1,1,'โปรแกรมที่ 1 ผ่อนคลาย \"วิถีชีวิตแม่กำปอง\" และออนเซน','หลังจากที่เหนื่อยล้าจากการทำงาน มาชาร์จแบต มาฮีลใจ มาสัมผัสอากาศ ฟื้นฟูสุขภาพกายใจ มาดูวิถีชีวิตของชาวบ้าน แม่กำปอง เป็นหมู่บ้านเล็กๆ ซ่อนตัวอยู่ท่ามกลางป่าเขาเขียวขจี มีความบริสุทธิ์ของธรรมชาติที่อุดมสมบูรณ์ ที่พักส่วนมากเป็นโฮมสเตย์ และเกือบทุกที่มีลำธารไหลผ่าน ป่าไม้หลากหลาย พรรณไม้ที่สมบูรณ์ คนอินกับต้นไม้คือต้องชอบแน่ๆ สภาพอากาศที่นี่จึงเย็นสบายตลอดปี','{\"start\":{\"time\":\"09:00\",\"note\":\"เดินทางถึง โรงพยาบาลแม่ออน Check-In Application Mae-On Wellness City\"},\"activities\":[{\"time\":\"09:00-10:00\",\"activityId\":1},{\"time\":\"10:00-11:00\",\"activityId\":2},{\"time\":\"11:00-13:00\",\"activityId\":3},{\"time\":\"13:00-14:30\",\"activityId\":4},{\"time\":\"14:30-15:00\",\"activityId\":5},{\"time\":\"15:00-15:30\",\"activityId\":6},{\"time\":\"15:30-16:00\",\"activityId\":7},{\"time\":\"16:00-16:20\",\"activityId\":8},{\"time\":\"17:00-17:40\",\"activityId\":9},{\"time\":\"17:40-19:10\",\"activityId\":10}],\"end\":{\"time\":\"19:10\",\"note\":\"Check-Out Application Mae-On Wellness City เดินทางกลับ\"}}',550.00,'เดินออกกำลังกาย สัมผัสธรรมชาติบรรยากาศดีๆ เรียนรู้วิถีชุมชน ผ่อนคลาย ฟื้นฟูสภาพกายใจ สร้างมิติ Wellness ในมิติร่างกาย (Physical) มิติอารมณ์หรือจิตใจ (Emotional/Psychological) มิติสังคม (Social) มิติสติปัญญาหรือองค์ความรู้ทางสุขภาพ (Intellectual/Cognitive) มิติอาชีวอนามัย (Occupational) มิติการเงิน (Financial) และ มิติสิ่งแวดล้อม (Environmental)',NULL,NULL,'2024-09-27 10:45:18','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant` (
  `id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `address` text NOT NULL,
  `contact` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`contact`)),
  `Interesting_menu` text DEFAULT NULL,
  `served_per_hour` int(11) DEFAULT NULL,
  `health` text DEFAULT NULL,
  `date_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`date_info`)),
  `service_fee` text DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slip_remaining`
--

DROP TABLE IF EXISTS `slip_remaining`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slip_remaining` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slip_remaining`
--

LOCK TABLES `slip_remaining` WRITE;
/*!40000 ALTER TABLE `slip_remaining` DISABLE KEYS */;
INSERT INTO `slip_remaining` VALUES
(1,3,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `slip_remaining` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subdistricts`
--

DROP TABLE IF EXISTS `subdistricts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subdistricts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subdistricts`
--

LOCK TABLES `subdistricts` WRITE;
/*!40000 ALTER TABLE `subdistricts` DISABLE KEYS */;
INSERT INTO `subdistricts` VALUES
(1,'ห้วยแก้ว','2024-09-27 10:16:30'),
(2,'แม่ทา','2024-09-27 10:16:30'),
(3,'ทาเหนือ','2024-09-27 10:16:30'),
(4,'บ้านสหกรณ์','2024-09-27 10:16:30'),
(5,'ออนกลาง','2024-09-27 10:16:30'),
(6,'ออนเหนือ','2024-09-27 10:16:30');
/*!40000 ALTER TABLE `subdistricts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(60) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `profile_picture` varchar(150) DEFAULT 'default-profile.jpg',
  `role` enum('USER','ADMIN','HOSPITAL','MERCHANT','TOUR','LEARNING_RESOURCE','HOTEL') DEFAULT 'USER',
  `usage_status` enum('OFFLINE','ONLINE') DEFAULT 'OFFLINE',
  `status_last_update` timestamp NULL DEFAULT current_timestamp(),
  `account_status` enum('DELETE','ACTIVE','SUSPEND') DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'test','test','test@gmail.com','$2b$04$qL225t1iWL1E2Y8km7sTjesIFb/5593iGfxJwjdBJ9HSt6C5KpUsW','0000000000','1-1727437636666.jpg','USER','OFFLINE','2024-10-07 15:24:10','ACTIVE','2024-09-27 10:16:30','2024-10-07 15:24:10'),
(2,'Akalak','Kruaboon','akalakkruaboon@gmail.com','$2b$04$uExRmBl8C.jXH5R5SDS9Q.4EAzwWJ3.q.SwIDwMFxck.EZHStY3GC','0902856188','2-1728732833629.jpg','USER','ONLINE','2024-10-14 17:02:25','ACTIVE','2024-09-27 10:16:30','2024-10-14 17:02:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2024-10-16 17:17:26

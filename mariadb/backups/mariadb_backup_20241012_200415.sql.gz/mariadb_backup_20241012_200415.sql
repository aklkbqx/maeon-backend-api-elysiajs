/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.5.2-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: maeon_db
-- ------------------------------------------------------
-- Server version	11.5.2-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES
('388639aa-e827-41d3-97a0-5a89c3aa5554','4ba64eea72335927a792e10870670b83e7b0718aac50953277c413893d602d3a','2024-09-27 11:37:12.637','20240927113712_init',NULL,NULL,'2024-09-27 11:37:12.571',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `location_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES
(1,'เจาะเลือด วัดความดัน เช็คค่าน้ำตาลในเลือด','ตรวจสุขภาพเบื้องต้น',60,50.00,1,'2024-09-25 08:04:49',NULL),
(2,'ย่างแคร่ และนวดแผนโบราณ','กิจกรรมปรับก่อนป่วย: บำบัดปวดตามศาสตร์แพทย์ล้านนา',60,200.00,3,'2024-09-25 08:04:49',NULL),
(3,'ชมธรรมชาติ วิถีชีวิตชุมชนแม่กำปอง','เยี่ยมชมศูนย์เรียนรู้แม่กำปอง',120,0.00,2,'2024-09-25 08:04:49',NULL),
(4,'ทำ/รับประทานอาหารเมนู \"ยำใบเมี่ยง ไข่ป่าม\"','เรียนรู้การทำอาหารพื้นเมือง',90,200.00,3,'2024-09-25 08:04:49',NULL),
(5,'ดื่มกาแฟ คอมบูชาแม่กำปอง','ลิ้มรสกาแฟท้องถิ่น',30,0.00,3,'2024-09-25 08:04:49',NULL),
(6,'ซื้อของฝากของที่ระลึกแม่กำปอง','เลือกซื้อผลิตภัณฑ์ท้องถิ่น เช่น หมอนใบเมี่ยง ถ่านอัดแท่ง',30,0.00,3,'2024-09-25 08:04:49',NULL),
(7,'เที่ยวน้ำตกแม่กำปอง','ชมความงามของน้ำตกในชุมชน',30,0.00,4,'2024-09-25 08:04:49',NULL),
(8,'ไหว้พระที่วัดคันธาพฤกษา','เยี่ยมชมวัดกลางน้ำ',20,0.00,5,'2024-09-25 08:04:49',NULL),
(9,'เดินชมถนนคนเดินแม่กำปอง','ชิมอาหารพื้นบ้าน ถ่ายรูปจุดต่างๆ',40,0.00,6,'2024-09-25 08:04:49',NULL),
(10,'ชมน้ำพุร้อนสันกำแพง ออนเซนแช่ตัว','ผ่อนคลายในน้ำพุร้อนธรรมชาติ',90,100.00,7,'2024-09-25 08:04:49',NULL),
(11,'เรียนรู้การปลูกผักออร์แกนิค','เรียนรู้การปลูกผักออร์แกนิค การทำพืชแนวกันชน และเก็บผักจากแปลง',180,0.00,8,'2024-09-25 08:12:44',NULL),
(12,'Workshop: Learning how to make organic','เรียนรู้วิธีการทำเกษตรอินทรีย์',60,0.00,8,'2024-09-25 08:12:44',NULL),
(13,'Workshop: Healthy cooking','เรียนรู้การทำอาหารเพื่อสุขภาพ',60,0.00,8,'2024-09-25 08:12:44',NULL),
(14,'Workshop: Vegetable planting','ฝึกปฏิบัติการปลูกผัก',60,0.00,8,'2024-09-25 08:12:44',NULL),
(15,'รับประทานเมนูสุขภาพ','เมนูสุขภาพ \"สลัดทูน่าผักออร์แกนิคแม่ทา\"',60,0.00,8,'2024-09-25 08:12:44',NULL),
(16,'ทัวร์ม่อนกุเวร','เยี่ยมชมและขอพรจากสิ่งศักดิ์สิทธิ์ต่างๆ บนม่อนกุเวร',60,0.00,9,'2024-09-25 08:12:44',NULL),
(17,'กิจกรรมเรียนรู้วิถีชาวนาปกาเกอะญอ (ภาคเช้า)','เรียนรู้การถอนกล้า ดำนา และเกี่ยวข้าว',180,0.00,10,'2024-09-25 08:16:16',NULL),
(18,'รับประทานอาหารกลางวันแบบปกาเกอะญอ','เมนูอาหารเพื่อสุขภาพตามวิถีปกาเกอะญอ',60,0.00,10,'2024-09-25 08:16:16',NULL),
(19,'กิจกรรมเรียนรู้วิถีชาวนาปกาเกอะญอ (ภาคบ่าย)','เรียนรู้การตีข้าว ตำข้าว และฝัดข้าว',60,0.00,10,'2024-09-25 08:16:16',NULL),
(20,'เยี่ยมชมวัดแม่ตะไคร้','ชมหลวงปู่ทวดองค์ใหญ่ที่สุดในโลก และสิ่งศักดิ์สิทธิ์อื่นๆ',40,0.00,11,'2024-09-25 08:16:16',NULL),
(21,'นั่งสมาธิที่ถ้ำแก้วเนรมิต','บำบัดจิตด้วยการนั่งสมาธิในถ้ำแก้วเนรมิต',20,0.00,11,'2024-09-25 08:16:16',NULL),
(22,'เยี่ยมชมอุทยานนรก','ชมการจัดแสดงวัฏจักรของการเกิด แก่ เจ็บ ตาย',20,0.00,11,'2024-09-25 08:16:16',NULL);
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `booking_detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `booking_date` date NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `people` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('PENDING','CONFIRMED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES
(1,2,'[{\"program_id\":1,\"program_name\":\"โปรแกรมที่ 1 ผ่อนคลาย \\\"วิถีชีวิตแม่กำปอง\\\" และออนเซน\"}]','2024-10-11','2024-10-12','2024-10-12',1,500.00,'CONFIRMED','2024-10-11 07:55:13','2024-10-12 08:06:59'),
(2,2,'[{\"program_id\":1,\"program_name\":\"โปรแกรมที่ 1 ผ่อนคลาย \\\"วิถีชีวิตแม่กำปอง\\\" และออนเซน\"}]','2024-10-11','2024-10-12','2024-10-12',5,1.00,'PENDING','2024-10-11 07:55:13','2024-10-12 11:01:02');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_types`
--

DROP TABLE IF EXISTS `location_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_types`
--

LOCK TABLES `location_types` WRITE;
/*!40000 ALTER TABLE `location_types` DISABLE KEYS */;
INSERT INTO `location_types` VALUES
(1,'สถานที่ท่องเที่ยว','2024-09-27 10:17:49','2024-10-08 22:12:21'),
(2,'ที่พัก','2024-10-08 21:39:03','2024-10-08 22:11:52'),
(3,'แหล่งเรียนรู้','2024-09-27 10:17:49','2024-10-08 21:38:34'),
(4,'ร้านอาหารและของฝาก','2024-09-27 10:17:49','2024-10-08 21:38:43'),
(5,'ท่องเที่ยวตามฤดูกาล','2024-10-08 21:39:03','2024-10-08 22:12:28'),
(6,'โรงพยาบาล','2024-09-27 10:17:49','2024-10-08 22:12:31');
/*!40000 ALTER TABLE `location_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `subdistrict_id` int(11) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `location_map` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`location_map`)),
  `time_slots` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `owner_id` int(11) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `subdistrict_id` (`subdistrict_id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`type`) REFERENCES `location_types` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `locations_ibfk_2` FOREIGN KEY (`subdistrict_id`) REFERENCES `subdistricts` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `locations_ibfk_3` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES
(1,'โรงพยาบาลแม่ออน',6,'โรงพยาบาลชุมชนในอำเภอแม่ออน','อำเภอแม่ออน จังหวัดเชียงใหม่',5,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:51:48','2024-10-12 13:03:18'),
(2,'แม่กำปอง',1,'หมู่บ้านเล็กๆ ซ่อนตัวอยู่ท่ามกลางป่าเขาเขียวขจี มีความบริสุทธิ์ของธรรมชาติที่อุดมสมบูรณ์','ตำบลห้วยแก้ว อำเภอแม่ออน จังหวัดเชียงใหม่',1,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:53:44','2024-10-12 13:03:20'),
(3,'ศูนย์เรียนรู้แม่กำปอง',3,'ศูนย์เรียนรู้วิถีชีวิตชุมชนแม่กำปอง','หมู่บ้านแม่กำปอง ตำบลห้วยแก้ว อำเภอแม่ออน จังหวัดเชียงใหม่',1,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:21'),
(4,'น้ำตกแม่กำปอง',1,'น้ำตกในชุมชนแม่กำปอง','หมู่บ้านแม่กำปอง ตำบลห้วยแก้ว อำเภอแม่ออน จังหวัดเชียงใหม่',1,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:23'),
(5,'วัดคันธาพฤกษา',1,'วัดกลางน้ำในชุมชนแม่กำปอง','หมู่บ้านแม่กำปอง ตำบลห้วยแก้ว อำเภอแม่ออน จังหวัดเชียงใหม่',1,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:23'),
(6,'ถนนคนเดินแม่กำปอง',1,'ถนนคนเดินในชุมชนแม่กำปอง มีอาหารพื้นบ้านและจุดถ่ายรูปหลากหลาย','หมู่บ้านแม่กำปอง ตำบลห้วยแก้ว อำเภอแม่ออน จังหวัดเชียงใหม่',1,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:24'),
(7,'น้ำพุร้อนสันกำแพง',1,'แหล่งน้ำพุร้อนธรรมชาติ','อำเภอสันกำแพง จังหวัดเชียงใหม่',4,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:25'),
(8,'กลุ่มผักออร์แกนิคแม่ทา',3,'ชุมชนเกษตรผสมผสานต้นแบบที่ปลูกผักออร์แกนิค','ตำบลแม่ทา อำเภอแม่ออน จังหวัดเชียงใหม่',2,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:26'),
(9,'ม่อนกุเวร',1,'แหล่งรวมสิ่งศักดิ์สิทธิ์ ขอพรเพื่อโชคลาภ','อำเภอแม่ออน จังหวัดเชียงใหม่',1,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:27'),
(10,'บ้านป่างิ้ว',3,'หมู่บ้านชาวปกาเกอะญอ ศูนย์เรียนรู้วิถีชีวิตชาวนา','ตำบลทาเหนือ อำเภอแม่ออน จังหวัดเชียงใหม่',3,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:28'),
(11,'วัดแม่ตะไคร้',1,'วัดเก่าแก่อายุกว่า 100 ปี มีหลวงปู่ทวดใหญ่และสูงที่สุดในโลก','ตำบลทาเหนือ อำเภอแม่ออน จังหวัดเชียงใหม่',3,NULL,'{\"latitude\":\"\",\"longitude\":\"\"}','[{\"start_time\":\"09:00:00\",\"end_time\":\"10:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"10:00:00\",\"end_time\":\"11:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"11:00:00\",\"end_time\":\"12:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"12:00:00\",\"end_time\":\"13:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"13:00:00\",\"end_time\":\"14:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"14:00:00\",\"end_time\":\"15:00:00\",\"note\":\"\",\"capacity\":4},{\"start_time\":\"15:00:00\",\"end_time\":\"16:00:00\",\"note\":\"\",\"capacity\":5},{\"start_time\":\"16:00:00\",\"end_time\":\"17:00:00\",\"note\":\"\",\"capacity\":5}]',1,1,'2024-09-25 17:55:02','2024-10-12 13:03:29');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `payment_method` enum('PROMPTPAY','BANK_ACCOUNT_NUMBER') DEFAULT NULL,
  `payment_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `slip_image` varchar(255) DEFAULT NULL,
  `status` enum('PENDING','PAID','FAILED','REFUNDED','PENDING_VERIFICATION','REJECTED') NOT NULL DEFAULT 'PENDING',
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `booking_id_2` (`booking_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,1,'PROMPTPAY',NULL,'2-1728676960281.jpeg','PAID','0041000600000101030040220014284130018COR076805102TH9104144A','2024-10-12 03:02:42','2024-10-11 07:55:13','2024-10-11 20:02:42'),
(2,2,'PROMPTPAY',NULL,NULL,'PENDING',NULL,'2024-10-12 03:02:42','2024-10-11 07:55:13','2024-10-12 08:09:23');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_images`
--

DROP TABLE IF EXISTS `program_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `program_id` int(11) NOT NULL,
  `image_name_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`image_name_data`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `program_id` (`program_id`),
  CONSTRAINT `program_images_ibfk_1` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_images`
--

LOCK TABLES `program_images` WRITE;
/*!40000 ALTER TABLE `program_images` DISABLE KEYS */;
INSERT INTO `program_images` VALUES
(1,1,'[\"Mae-Kampong-Chiang-Mai-02.jpg\",\"maxresdefault (1).jpg\"]','2024-09-27 23:07:05',NULL),
(2,2,'[\"maxresdefault.jpg\"]','2024-09-27 23:07:05',NULL),
(3,3,'[\"1659434714_876589-chiangmainews.jpg\"]','2024-09-27 23:07:05',NULL);
/*!40000 ALTER TABLE `program_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_types`
--

DROP TABLE IF EXISTS `program_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_types`
--

LOCK TABLES `program_types` WRITE;
/*!40000 ALTER TABLE `program_types` DISABLE KEYS */;
INSERT INTO `program_types` VALUES
(1,'โปรแกรมระยะสั้น (One-day trip)','8 มิติ Wellness ใน 8 โปรแกรมท่องเที่ยว เป็นโปรแกรมการท่องเที่ยวระยะสั้นที่จะได้ทั้งผ่อนคลายได้ท่องเที่ยวเรียนรู้ไปกับสถานที่ต่างๆภายใน 1 วันเต็ม','2024-09-25 17:55:26',NULL),
(2,'โปรแกรมฟื้นฟูสุขภาพ (Long-day trip)','โปรแกรมท่องเที่ยวระยะยาวที่จะให้นักท่องเที่ยวได้ไปท่องเที่ยวหลายวันตามโปรแกรมที่กำหนด และยังได้การฟื้นฟูสุขภาพที่ดีขึ้นอีกด้วย','2024-09-25 17:55:26',NULL),
(3,'โปรแกรมการท่องเที่ยวด้วยตัวเอง','กิจกรรมการท่องเที่ยวรูปแบบต่างๆ แยกตามตำบลของอำเภอแม่ออน ที่นักท่องเที่ยวสามารถจัดสรรค์เวลา เลือกจองการท่องเที่ยวเพื่อสุขภาพที่ไหนเองก็ได้ตามใจชอบ','2024-09-25 17:55:26',NULL);
/*!40000 ALTER TABLE `program_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `schedules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`schedules`)),
  `total_price` decimal(8,2) NOT NULL,
  `wellness_dimensions` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `programs_ibfk_1` FOREIGN KEY (`type`) REFERENCES `program_types` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `programs_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES
(1,1,'โปรแกรมที่ 1 ผ่อนคลาย \"วิถีชีวิตแม่กำปอง\" และออนเซน','หลังจากที่เหนื่อยล้าจากการทำงาน มาชาร์จแบต มาฮีลใจ มาสัมผัสอากาศ ฟื้นฟูสุขภาพกายใจ มาดูวิถีชีวิตของชาวบ้าน แม่กำปอง เป็นหมู่บ้านเล็กๆ ซ่อนตัวอยู่ท่ามกลางป่าเขาเขียวขจี มีความบริสุทธิ์ของธรรมชาติที่อุดมสมบูรณ์ ที่พักส่วนมากเป็นโฮมสเตย์ และเกือบทุกที่มีลำธารไหลผ่าน ป่าไม้หลากหลาย พรรณไม้ที่สมบูรณ์ คนอินกับต้นไม้คือต้องชอบแน่ๆ สภาพอากาศที่นี่จึงเย็นสบายตลอดปี','{\"start\":{\"time\":\"09:00\",\"note\":\"เดินทางถึง โรงพยาบาลแม่ออน Check-In Application Mae-On Wellness City\"},\"activities\":[{\"time\":\"09:00-10:00\",\"activityId\":1},{\"time\":\"10:00-11:00\",\"activityId\":2},{\"time\":\"11:00-13:00\",\"activityId\":3},{\"time\":\"13:00-14:30\",\"activityId\":4},{\"time\":\"14:30-15:00\",\"activityId\":5},{\"time\":\"15:00-15:30\",\"activityId\":6},{\"time\":\"15:30-16:00\",\"activityId\":7},{\"time\":\"16:00-16:20\",\"activityId\":8},{\"time\":\"17:00-17:40\",\"activityId\":9},{\"time\":\"17:40-19:10\",\"activityId\":10}],\"end\":{\"time\":\"19:10\",\"note\":\"Check-Out Application Mae-On Wellness City เดินทางกลับ\"}}',550.00,'เดินออกกำลังกาย สัมผัสธรรมชาติบรรยากาศดีๆ เรียนรู้วิถีชุมชน ผ่อนคลาย ฟื้นฟูสภาพกายใจ สร้างมิติ Wellness ในมิติร่างกาย (Physical) มิติอารมณ์หรือจิตใจ (Emotional/Psychological) มิติสังคม (Social) มิติสติปัญญาหรือองค์ความรู้ทางสุขภาพ (Intellectual/Cognitive) มิติอาชีวอนามัย (Occupational) มิติการเงิน (Financial) และ มิติสิ่งแวดล้อม (Environmental)',NULL,'2024-09-27 10:45:18','2024-09-27 15:49:41'),
(2,2,'โปรแกรมที่ 2 กินเพื่อสุขภาพด้วย \"ผักออร์แกนิค\" และบำบัดจิต','เรียนรู้การฟื้นฟูชีวิตด้วยผักออร์กานิค จากชุมชนที่ได้รับการสำรวจว่ายากจนที่สุด \"มีหนี้สินเยอะที่สุดในจังหวัดเชียงใหม่\" สู่ชุมชนเกษตรผสมผสานต้นแบบ ที่เต็มไปด้วยความอุดมสมบูรณ์ ความสุข และความยั่งยืนทางธุรกิจตั้งแต่ต้นน้ำ กลางน้ำ และปลายน้ำ ในปัจจุบัน สร้างรายได้ให้ชุมชนมากกว่า 400,000 บาทต่อเดือน มาเที่ยวเพื่อดูแลสุขภาพ พักฟื้น พักผ่อน ในพื้นที่ปลอดภัย ทั้งอาหาร อากาศ สังคม และสิ่งแวดล้อมด้วย \"วิถีอินทรีย์\"','{\"start\":{\"time\":\"09:00\",\"note\":\"เดินทางถึงตำบลแม่ทา Check-In Application Mae-On Wellness City ณ กลุ่มผักออร์แกนิคแม่ทา\"},\"activities\":[{\"time\":\"09:00-12:00\",\"activityId\":11},{\"time\":\"12:00-13:00\",\"activityId\":12},{\"time\":\"13:00-14:00\",\"activityId\":13},{\"time\":\"14:00-15:00\",\"activityId\":14},{\"time\":\"15:00-16:00\",\"activityId\":15},{\"time\":\"16:00-17:00\",\"activityId\":16},{\"time\":\"17:00-18:00\",\"activityId\":1},{\"time\":\"18:00-19:00\",\"activityId\":2}],\"end\":{\"time\":\"19:00\",\"note\":\"Check-Out Application Mae-On Wellness City เดินทางกลับ\"}}',250.00,'เสริมเพิ่มวิตามินจากเมนูผักออร์กานิคเพื่อสุขภาพ เห็นคุณค่าของการกินเพื่อสุขภาพ และบำบัดสุขภาพจิตใจ สร้างมิติ Wellness ในมิติร่างกาย (Physical) มิติอารมณ์หรือจิตใจ (Emotional/Psychological) มิติสังคม (Social) มิติสติปัญญาหรือองค์ความรู้ทางสุขภาพ (Intellectual/Cognitive) มิติจิตวิญญาณ (Spiritual) มิติอาชีวอนามัย (Occupational) มิติการเงิน (Financial) และ มิติสิ่งแวดล้อม (Environmental)',NULL,'2024-09-27 10:59:37','2024-09-27 23:02:44'),
(3,1,'โปรแกรมที่ 3 ดำนาปลูกข้าวตามวิถี \"ชาวนาปกาเกอะญอ\" และบำบัดจิต','เรียนรู้วิถีชีวิตชาวนาปกาเกอะญอ พร้อมทำกิจกรรมบำบัดจิตและตรวจสุขภาพ เป็นโปรแกรมที่ให้ประสบการณ์การทำนาแบบดั้งเดิม และเยี่ยมชมสถานที่ศักดิ์สิทธิ์เพื่อบำบัดจิตใจ','{\"start\":{\"time\":\"09:00\",\"note\":\"เดินทางถึง บ้านป่างิ้ว ตำบลทาเหนือ Check-In Application Mae-On Wellness City\"},\"activities\":[{\"time\":\"09:00-12:00\",\"activityId\":17},{\"time\":\"12:00-13:00\",\"activityId\":18},{\"time\":\"13:00-14:00\",\"activityId\":19},{\"time\":\"14:00-14:40\",\"activityId\":20},{\"time\":\"14:40-15:00\",\"activityId\":21},{\"time\":\"15:00-15:20\",\"activityId\":22},{\"time\":\"17:00-18:00\",\"activityId\":1},{\"time\":\"18:00-19:00\",\"activityId\":2}],\"end\":{\"time\":\"19:00\",\"note\":\"Check-Out Application Mae-On Wellness City เดินทางกลับ\"}}',250.00,'ออกกำลังกาย เผาผลาญอาหาร เห็นคุณค่าของการกินเพื่อสุขภาพ บำบัดจิตฝึกสมาธิ สร้างมิติ Wellness ในมิติร่างกาย (Physical) มิติอารมณ์หรือจิตใจ (Emotional/Psychological) มิติสังคม (Social) มิติสติปัญญาหรือองค์ความรู้ทางสุขภาพ (Intellectual/Cognitive) มิติจิตวิญญาณ (Spiritual) มิติอาชีวอนามัย (Occupational) มิติการเงิน (Financial) และ มิติสิ่งแวดล้อม (Environmental)',NULL,'2024-09-27 10:59:37','2024-09-27 15:50:02');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slip_remaining`
--

DROP TABLE IF EXISTS `slip_remaining`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slip_remaining` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slip_remaining`
--

LOCK TABLES `slip_remaining` WRITE;
/*!40000 ALTER TABLE `slip_remaining` DISABLE KEYS */;
INSERT INTO `slip_remaining` VALUES
(1,3);
/*!40000 ALTER TABLE `slip_remaining` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subdistricts`
--

DROP TABLE IF EXISTS `subdistricts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subdistricts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subdistricts`
--

LOCK TABLES `subdistricts` WRITE;
/*!40000 ALTER TABLE `subdistricts` DISABLE KEYS */;
INSERT INTO `subdistricts` VALUES
(1,'ห้วยแก้ว','2024-09-27 10:16:30',NULL),
(2,'แม่ทา','2024-09-27 10:16:30',NULL),
(3,'ทาเหนือ','2024-09-27 10:16:30',NULL),
(4,'บ้านสหกรณ์','2024-09-27 10:16:30',NULL),
(5,'ออนกลาง','2024-09-27 10:16:30',NULL),
(6,'ออนเหนือ','2024-09-27 10:16:30',NULL);
/*!40000 ALTER TABLE `subdistricts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(60) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `profile_picture` varchar(150) DEFAULT 'default-profile.jpg',
  `role` enum('USER','ADMIN','HOSPITAL','MERCHANT','TOUR','LEARNING_RESOURCE','HOTEL','SEASONAL_TRAVEL') DEFAULT 'USER',
  `usage_status` enum('OFFLINE','ONLINE') DEFAULT 'OFFLINE',
  `status_last_update` timestamp NULL DEFAULT current_timestamp(),
  `account_status` enum('DELETE','ACTIVE','SUSPEND') DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'test','test','test@gmail.com','$2b$04$qL225t1iWL1E2Y8km7sTjesIFb/5593iGfxJwjdBJ9HSt6C5KpUsW','0000000000','1-1727437636666.jpg','USER','OFFLINE','2024-10-07 15:24:10','ACTIVE','2024-09-27 10:16:30','2024-10-07 15:24:10'),
(2,'Akalak','Kruaboon','akalakkruaboon@gmail.com','$2b$04$uExRmBl8C.jXH5R5SDS9Q.4EAzwWJ3.q.SwIDwMFxck.EZHStY3GC','0902856188','2-1728732833629.jpg','USER','ONLINE','2024-10-12 12:21:33','ACTIVE','2024-09-27 10:16:30','2024-10-12 12:21:33');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2024-10-12 20:04:16
